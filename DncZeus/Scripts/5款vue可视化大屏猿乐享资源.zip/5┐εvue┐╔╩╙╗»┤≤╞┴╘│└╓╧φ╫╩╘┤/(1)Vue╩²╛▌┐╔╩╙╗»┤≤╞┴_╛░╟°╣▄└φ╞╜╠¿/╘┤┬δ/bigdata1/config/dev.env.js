'use strict'
const merge = require('webpack-merge')
const prodEnv = require('./prod.env')
// Copyright © 青 岛 研 锦 网 络 科 技 有 限 公 司  版权所有.
module.exports = merge(prodEnv, {
  NODE_ENV: '"development"'
})
