<template>
  <div class="as">
    <h1>{{ msg }}</h1>
  </div>
</template>

<script>
export default {
  name: 'as',
  data () {
    return {
      msg: '11111111111111111111111p'
    }
  }
}
</script>
<style>

</style>

