<template>
  <div class="bs">
    <h1>{{ msg }}</h1>
  </div>
</template>

<script>
export default {
  name: 'bs',
  data () {
    return {
      msg: '2222222222222222222222'
    }
  }
}
</script>
