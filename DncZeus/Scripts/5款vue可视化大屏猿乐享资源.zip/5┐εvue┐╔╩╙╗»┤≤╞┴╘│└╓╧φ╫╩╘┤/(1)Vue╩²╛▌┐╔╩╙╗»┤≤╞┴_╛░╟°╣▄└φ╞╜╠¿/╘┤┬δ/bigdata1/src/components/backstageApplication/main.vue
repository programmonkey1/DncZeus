<template>
  <div class="backstageapplication">
      <div class="inner-backstage clearfix">
          <div class="lf left-backstage">
                <div class="clearfix">
                  <div class="lf intelligentService">
                        <h3 class="title-service">智慧服务</h3>
                        <div class="clearfix">
                            <div class="lf once-tips">
                                <div class="h12 yellow border">
                                    <span class="icon-dlxx"></span>
                                    <p>地理信息系统</p>
                                </div>
                                <div class="h12 green border">
                                    <span class="icon-ht2"></span>
                                    <p>编码服务</p>
                                </div>
                                <div class="h157 blue border">
                                    <span class="icon-ht3"></span>
                                    <p>景区设施</p>
                                    <p class="second-p">坐标采集服务</p>
                                </div>
                            </div>
                            <div class="lf two-tips">
                                <div class="h157 orange border">
                                    <span class="icon-ht4"></span>
                                    <p class="zdp">自助导览系统</p>
                                </div>
                                <div class="h12 zise border">
                                    <span class="icon-ht5"></span>
                                    <p>电子广播系统</p>
                                </div>
                                <div class="h12 meihong border">
                                    <span class="icon-ht6"></span>
                                    <p>投诉管理系统</p>
                                </div>
                            </div>
                            <div class="lf three-tips">
                                <div class="h12 shenlv border">
                                    <span class="icon-ht7"></span>
                                    <p>信息发布系统</p>
                                </div>
                                <div class="h12 shenlan border">
                                    <div class="h12 shenlv border">
                                        <span class="icon-ht8"></span>
                                        <p>停车场管理系统</p>
                                    </div>
                                </div>
                                <div class="callCenter border">
                                    <span class="icon-ht24"></span>
                                    <p class="zdp">呼叫中心管理</p>
                                </div>
                            </div>
                        </div>
                  </div>
                  <div class="lf service-right">
                        <h3 class="title-service">智慧营销</h3>
                            <div class="clearfix">
                                <div class="lf two-tips">
                                    <div class="h157  zise border">
                                        <span class="icon-ht9"></span>
                                        <p class="zdp">B2C电商系统</p>
                                    </div>
                                    <div class="h12 yellow border">
                                        <span class="icon-ht10"></span>
                                        <p>信息发布系统</p>
                                    </div>
                                    <div class="h12 meihong border">
                                        <span class="icon-ht11"></span>
                                        <p>景区消费系统</p>
                                    </div>
                                </div>
                                <div class="lf once-tips">
                                    <div class="h12 green border">
                                        <span class="icon-ht12"></span>
                                        <p>景区官网管理</p>
                                    </div>
                                    <div class="h12 shenlan border">
                                        <span class="icon-ht25"></span>
                                        <p class="piaop">票务管理系统</p>
                                        <p class="piaop-p">（闸机检票）</p>
                                    </div>
                                    <div class="h157 blue border">
                                        <div class="h157 blue border">
                                            <span class="icon-ht13"></span>
                                            <p>景区微信</p>
                                            <p class="second-p">公众号管理</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                </div>
                <div class="scenicSpots">
                    <h3 class="title-service">景区大数据</h3>
                    <div class="scenic-cont clearfix">
                        <div class="lf comsrot orange">
                            <div class="clearfix">
                                <span class="lf icon-ht22"></span>
                                <p class="lf specil-p">大数据采集</p>
                            </div>
                        </div>
                        <div class="lf comsrot shenlan">
                            <span class="lf icon-ht23"></span>
                            <p class="lf specil-p1">大数据建模</p>
                        </div>
                        <div class="lf comsrot zise">
                            <span class="lf icon-ht29"></span>
                            <p class="lf specil-p">大数据分析展现</p>
                        </div>
                    </div>
                </div>
          </div>
          <div class="lf right-backstage">
              <h3 class="title-service">智慧管理</h3>
              <div class="clearfix">
                <div class="once-tips lf">
                    <div class="h12 yellow border">
                        <span class="icon-ht26"></span>
                        <p>排班管理</p>
                    </div>
                    <div class="h165 zise border">
                        <span class="icon-ht14"></span>
                        <p class="zdp">资源管理</p>
                    </div>
                </div>
                <div class="once-tips lf">
                    <div class="h165 meihong border">
                        <span class="icon-ht15"></span>
                        <p class="zdp">应急管理</p>
                    </div>
                    <div class="h12 orange border">
                        <span class="icon-ht16"></span>
                        <p>办公管理</p>
                    </div>
                </div>
                <div class="once-tips lf mr0 w148">
                    <div class="h12 shenlan border">
                        <span class="icon-ht27"></span>
                        <p>招商管理</p>
                    </div>
                    <div class="h165 shenlv border ">
                        <span class="icon-ht28"></span>
                        <p class="zdp">线路管理</p>
                    </div>
                </div>
              </div>
              <div class="h157  clearfix">
                  <div class="lf video-manage h157 yellow border">
                      <span class="icon-ht17"></span>
                      <p>视频管理</p>
                  </div>
                  <div class="lf shenlvs h157 shenlv border">
                        <span class="icon-ht18"></span>
                        <p class="zdp">资源管理</p>
                  </div>
              </div>
              <div class="h157  clearfix">
                  <div class="lf h157 shenlan border">
                        <span class="icon-ht19"></span>
                        <p class="zdp">车辆管理</p>
                  </div>
                  <div class="lf  shenlvs h157 zise border">
                        <span class="icon-ht20"></span>
                        <p class="zdp">司机管理</p>
                  </div>
                  <div class="lf shenlvs h157 orange border">
                        <span class="icon-ht21"></span>
                        <p class="zdp">巡检管理</p>
                  </div>
              </div>
          </div>
      </div>
  </div>
</template>

<script>
export default {
  name: 'backstageApplication',
  components: {

  }
}
</script>
<style scoped>
.backstageapplication{width: 100%; background: url(../../../static/images/bg.jpg) no-repeat; height: 8.76rem; background-size: 100%}
.backstageapplication .inner-backstage{width: 72.8%; margin: 0 auto; padding-top: .7rem; height: 7rem}
.backstageapplication .intelligentService{ margin-right: .6rem;}
.backstageapplication .title-service{font-size: 18px; color: #fff; font-weight: normal;padding-bottom:.12rem;}
.backstageapplication .left-backstage{margin-right: .58rem}
.backstageapplicatioright{width: 4.79rem; }
.backstageapplication .once-tips{width:1.49rem; margin-right:.11rem;}
.backstageapplication .border{border-radius: 4px; margin-top: .1rem; width: 1.49rem;}
.backstageapplication .h12{height: 1.2rem;}
.backstageapplication .two-tips{width:1.49rem; margin-right: .1rem}
.backstageapplication .h157{height: 1.57rem; }
.backstageapplication .h12{height: 1.2rem}
.backstageapplication .h165{height: 1.65rem}
.backstageapplication .callCenter{background: #e6ba01; height: 1.57rem}
.yellow{background: #e6ba01;}
.green{background: #689f0e;}
.blue{background: #03be87}
.orange{background: #ed6e07}
.zise{background: #9b36e3}
.meihong{background: #ce045a;}
.shenlan{background: #5292f4;}
.shenlv{background: #03be87}
.backstageapplication .scenicSpots{margin-top: .55rem;}
.backstageapplication .scenic-cont{height: 1.36rem; width: 100%; background: rgba(0,0,0,.5); border-radius: 2px}
.backstageapplication .comsrot{height: 1.1rem;width: 31.3%; margin-top: .13rem;  border-radius: 4px; margin-left: .13rem}
.backstageapplication .service-right .once-tips{margin-right: 0}
.right-backstage{width: 34.7%;}
.backstageapplication .mr0{margin-right: 0}
.backstageapplication .w148{width:1.46rem;}
.backstageapplication .video-manage{width: 3.08rem;}
.backstageapplication .shenlvs{width: 1.48rem; margin-left: .1rem}
.icon-dlxx:before {margin-left:-.25rem;  top: .2rem; position: relative; left: 50%; font-size: .5rem}
.backstageapplication p{font-size: .16rem; color: #fff; padding-top: .3rem; text-align: center}
.icon-ht2:before {margin-left:-.23rem; top: .25rem;color: #fff;font-size: .46rem;  top: .2rem; position: relative; left: 50%;}
.icon-ht3:before,.icon-ht13:before {margin-left:-.3rem;color: #fff; font-size: .6rem;top: .2rem; position: relative; left: 50%;}
.backstageapplication p.second-p{ padding-top: .03rem}
.icon-ht4:before,.icon-ht24:before,.icon-ht9:before,.icon-ht14:before,.icon-ht15:before,.icon-ht28:before,.icon-ht18:before,.icon-ht19:before,.icon-ht20:before,.icon-ht21:before{color: #fff;font-size: .6rem; margin-left: -.3rem; top: .3rem;  position: relative;left: 50%; }
.icon-ht5:before,.icon-ht6:before,.icon-ht7:before,.icon-ht8:before,.icon-ht10:before,.icon-ht11:before,.icon-ht12:before,.icon-ht25:before,.icon-ht26:before,.icon-ht16:before,.icon-ht27:before{color: #fff;font-size: .5rem;top: .2rem; margin-left: -.25rem;position: relative;left: 50%; }
.backstageapplication .zdp{padding-top: .45rem}
.backstageapplication .piaop{ padding-top: .1rem}
.backstageapplication .piaop-p{padding-top: 0}
.icon-ht25:before{top: .1rem }
.icon-ht26:before{font-size: .52rem; margin-left: -.26rem}
.icon-ht14:before{top: .3rem; font-size: .64rem; margin-left:-.32rem}
.icon-ht15:before{top: .35rem}
.icon-ht28:before{font-size:.66rem; margin-left: -.33rem;top: .35rem}
.icon-ht17:before{font-size:.8rem; margin-left: -.4rem;top: .25rem;color: #fff; left: 50%; position: relative}
.icon-ht22:before,.icon-ht23:before,.icon-ht29:before{font-size:.75rem;top: .18rem;color: #fff; left:.4rem; position: relative}
.backstageapplication .specil-p{margin-left: .5rem; padding-top: .42rem}
.backstageapplication .specil-p1{margin-left: .56rem;padding-top: .42rem}
.icon-ht29:before{left:.37rem}
</style>
