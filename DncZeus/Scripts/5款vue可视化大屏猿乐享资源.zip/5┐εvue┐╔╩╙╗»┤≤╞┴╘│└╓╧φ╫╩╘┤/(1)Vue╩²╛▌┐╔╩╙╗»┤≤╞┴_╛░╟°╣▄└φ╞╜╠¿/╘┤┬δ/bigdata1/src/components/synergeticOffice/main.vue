<template>
  <div class=" synergeticOffice mt22 clearfix"> 
    <new-notice></new-notice>
  </div>
</template>

<script>
import newNotice from './newNotice'
export default {
  name: 'synergeticOffice',
  components: {     
    'new-notice': newNotice
  }
}
</script>
<style>
</style>
