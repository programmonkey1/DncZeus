[
    {type:"种子植物",name:'马尾松',introduce:'乔木','imgs':'../../../static/images/1.jpg'},
    {type:"孢子植物",name:'蘑菇',introduce:'蘑菇科','imgs':'../../../static/images/2.png'},
    {type:"裸子植物",name:'银杏',introduce:'落叶乔木','imgs':'../../../static/images/1.jpg'},
    {type:"种子植物",name:'马尾松',introduce:'乔木','imgs':'../../../static/images/2.png'}
]