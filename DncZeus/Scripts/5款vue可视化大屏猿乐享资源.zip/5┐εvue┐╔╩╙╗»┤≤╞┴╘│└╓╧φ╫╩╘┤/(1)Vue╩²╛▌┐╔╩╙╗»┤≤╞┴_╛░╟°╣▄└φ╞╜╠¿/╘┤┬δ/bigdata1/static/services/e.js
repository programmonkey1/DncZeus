[
    {type:"哺乳动物",name:'长颈鹿',introduce:'哺乳类、偶蹄目','imgs':'../../../static/images/2.png'},
    {type:"雀科动物",name:'麻雀',introduce:'雀科雀属的鸟类','imgs':'../../../static/images/1.png'},
    {type:"蚁科动物",name:'蚂蚁',introduce:'昆虫、节肢动物门','imgs':'../../../static/images/1.png'},
    {type:"哺乳动物",name:'马尾松',introduce:'哺乳类、偶蹄目','imgs':'../../../static/images/2.png'}
]