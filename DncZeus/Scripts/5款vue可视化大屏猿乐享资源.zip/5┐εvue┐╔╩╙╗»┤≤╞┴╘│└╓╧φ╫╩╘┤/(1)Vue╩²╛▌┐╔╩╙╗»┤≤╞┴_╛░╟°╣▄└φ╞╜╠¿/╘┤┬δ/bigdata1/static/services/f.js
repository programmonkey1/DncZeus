[
    {type:"松软土",name:'疏松的种植土、淤泥','imgs':'../../../static/images/3.png'},
    {type:"普通土",name:'粉质粘土','imgs':'../../../static/images/1.png'},
    {type:"砂砾坚土",name:'疏松的种植土、淤泥','imgs':'../../../static/images/2.png'},
    {type:"砂砾坚土",name:'坚硬密实的粘性土或黄土','imgs':'../../../static/images/1.png'}
]