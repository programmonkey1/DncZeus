{
  "data":[{
    "id": 2,
    "title": "拥挤指数",
    "type": 1,
    "numericalvalue": 3,
    "status": 1,
    "addtime": 1523151356000
  }, {
    "id": 17,
    "title": "购票人数",
    "type": 2,
    "numericalvalue": 3000,
    "status": 1,
    "addtime": 1523243313000
  }, {
    "id": 18,
    "title": "入园人数",
    "type": 3,
    "numericalvalue": 2000,
    "status": 1,
    "addtime": 1523243335000
  }],
  "msg":"200"
}
