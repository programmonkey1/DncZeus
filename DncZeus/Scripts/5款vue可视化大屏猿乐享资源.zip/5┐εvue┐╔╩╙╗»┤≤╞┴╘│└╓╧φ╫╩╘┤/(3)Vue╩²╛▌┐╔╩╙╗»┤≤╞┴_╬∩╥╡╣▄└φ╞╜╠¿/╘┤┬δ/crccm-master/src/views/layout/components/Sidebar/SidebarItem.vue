<template>
  <div class="menu-wrapper">
   1111
  </div>
</template>

<script>
export default {
  name: 'SidebarItem',
  
}
</script>
