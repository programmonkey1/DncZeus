// 青岛研锦网络科技有限公司 版权所有
'use strict';
module.exports = {
  NODE_ENV: '"production"',
  BASE_API: '"/ovu-screen/pcos"'
};
