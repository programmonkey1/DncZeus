<template>
    <div id="app">
        <router-view/>
    </div>
</template>

<script>
/* const MENULIST = [] */

export default {
  name: 'App'
};
</script>

<style lang="scss">
//@import "normalize.css/normalize.css"; /* normalize */
//@import "./styles/index.scss";
</style>
