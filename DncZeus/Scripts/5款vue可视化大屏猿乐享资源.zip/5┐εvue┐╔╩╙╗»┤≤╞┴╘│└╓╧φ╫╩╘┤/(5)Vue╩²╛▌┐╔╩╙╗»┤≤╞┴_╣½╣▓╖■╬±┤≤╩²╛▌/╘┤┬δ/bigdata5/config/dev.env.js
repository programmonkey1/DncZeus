'use strict'
const merge = require('webpack-merge')
const prodEnv = require('./prod.env')
// Copyright © 青岛研锦网络科技有限公司 版权所有
module.exports = merge(prodEnv, {
  NODE_ENV: '"development"'
})
