<template>
    <div class="lineTem">
        <h3>{{title}}</h3>
        <div id="lineChartTem" class="lineChartTem">

        </div>
    </div>
</template>

<script>
export default {
    props:['pageType'],
    watch:{
        pageType(newval){
            if(this.pageType=='tem-city'){
                this.title = '温州市(58659)24小时逐小时温度|℃'
            }else if(this.pageType=='tem-county'){
                this.title = '永嘉县(58659)24小时逐小时温度|℃'
            }
        }
    },
    data(){
        return{
            title:'',
            options:{
                tooltip: {
                    trigger: 'axis',
                   formatter:(params)=>{
                       console.log(params)
                       return params[0].name+'时 : '+params[0].value+'℃'
                   }
                },
                grid: {
                    left: '3%',
                    right: '4%',
                    bottom: '6%',
                    top:'10%',
                    containLabel: true
                },
                xAxis: {
                    type: 'category',
                    boundaryGap: false,
                    axisTick: {
                        show:false,
                    },
                    axisLine:{
                        lineStyle:{
                            color:'#0A3857',
                        }
                    },
                    axisLabel:{
                        color:'#83C3E9'
                    },
                    data: []
                },
                yAxis: {
                    type: 'value',
                        axisLine:{
                            lineStyle:{
                                color:'#0A3857',
                            }
                        },
                        axisTick: {
                            show:false,
                        },
                        axisLabel:{
                            color:'#83C3E9'
                        },
                        splitLine:{
                            lineStyle:{
                                color:'#0A3857',
                            }
                        }
                },
                series: [{
                    data: [25,21,18,16,14,13,12,13,14,16,18,21,25,27,24,21,19,17,16,15,15,14,12,11],
                    type: 'line',
                    symbol:'none',
                     emphasis:{
                        label:{
                            show:false,
                        }
                    },
                    areaStyle: {
                        normal: {
                            color: new this.$echarts.graphic.LinearGradient(0, 0, 0, 1, [
                              { offset: 0, color: "rgb(230, 208, 84)" },
                              { offset: 1, color: "rgba(230, 208, 84,0)" }
                            ])
                        }
                    },
                    lineStyle:{
                        normal:{color:'#69EABA'},
                    },
                    markPoint: {
                        symbol: "circle", 
                        symbolSize: 6,
                        label:{
                            position:'top',
                            color:'#ECCEAA',
                            rich:{
                                min:{
                                    color:'#52DCC2'
                                }
                            },
                            formatter:(val=>{
                                if(val.name=='最小值'){
                                    return '{min|'+val.value+'℃}'
                                }else{
                                     return val.value+'℃'
                                }
                            })
                        },
                        itemStyle:{
                            color:'#0E5F0D',
                            borderColor: '#DEFF84',
                            borderWidth: 1,
                            borderType: 'solid',
                        },
                        data: [
                            {type: 'max', name: '最大值'},
                            {type: 'min', name: '最小值'}
                        ]
                    },
                    smooth:true,
                }]
            }
        }
    },
    methods:{
        group(array, subGroupLength) {
            let index = 0;
            let newArray = [];
            while(index < array.length) {
                newArray.push(array.slice(index, index += subGroupLength));
            }
            return newArray;
        },
        getTime(){
            let time = new Date().getHours()
            let timeArr = Array.from({length: 24}, (v, i) => (i+'').padStart(2,'0'));
            let end = timeArr.splice(time+1,23)
            return end.concat(timeArr)
        },
        initCharts(){
            this.options.xAxis.data = this.getTime()
            let lineChartTem = document.getElementById('lineChartTem')
            let fsize = document.body.clientWidth/1920*16
            lineChartTem.style.height = document.body.clientWidth<=1920? fsize*15+'px':'15rem'
            var myChart = this.$echarts.init(lineChartTem); 
            myChart.setOption(this.options)
        }
    },
    created(){
        if(this.pageType=='tem-city'){
            this.title = '温州市(58659)24小时逐小时温度|℃'
        }else if(this.pageType=='tem-county'){
            this.title = '永嘉县(58659)24小时逐小时温度|℃'
        }
    },
    mounted(){
        this.initCharts()
        this.getTime()
    }
}
</script>
<style lang="scss" scoped>
    .lineTem{
        width:100%;
        height:100%;
        display:flex;
        flex-direction: column;
        position: relative;
        // background-color: rgb(230, 208, 84);
        h3{
            line-height:2.3rem;
            letter-spacing: .2rem;
            font-size:1.2rem;
            text-align:center;
            height:2.3rem;
            border:.1rem solid rgba(48, 138, 199, 0.5);
            box-shadow: 0rem 0rem .5rem .1rem rgba(48, 138, 199, 0.5) inset;
            width:25rem;
        }
        .lineChartTem{ 
            // height:15rem;
            margin-top:.5rem;
            background: linear-gradient( rgba(4, 15, 50,.2), rgba(4, 15, 50,.8),rgba(4, 15, 50,.2));
        }
    }
</style>