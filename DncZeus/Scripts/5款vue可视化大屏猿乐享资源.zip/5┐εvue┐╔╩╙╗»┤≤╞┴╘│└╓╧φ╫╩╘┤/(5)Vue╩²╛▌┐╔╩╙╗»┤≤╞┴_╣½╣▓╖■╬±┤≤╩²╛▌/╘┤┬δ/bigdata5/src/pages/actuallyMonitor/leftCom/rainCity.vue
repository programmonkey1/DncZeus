<template>
<!-- 市区   降雨 -->
    <div class="rainCity">
        <fan-chart class="fanChart"/>
        <county-bar class="countyBar" :pageType="pageType"/>
        <squared-nine class="squaredNine" :pageType="pageType"/>
    </div>
</template>

<script>
import fanChart from './branch/fanChart'
import countyBar from './branch/countyBar'
import squaredNine from './branch/squaredNine'
export default {
    props:['pageType'],// to textInfo
    components:{
        fanChart,
        countyBar,
        squaredNine
    },
    watch:{
    }
}
</script>

<style lang="scss" scoped>
    .rainCity{
        width:100%;
        height:100%;
        display:flex;
        flex-direction: column;
        .fanChart{
            height:14rem;
        }
        .countyBar{
            width:100%;
            margin:1.5rem 0;
            height:23rem;
        }
        .squaredNine{
            flex:1;
        }
    }
</style>