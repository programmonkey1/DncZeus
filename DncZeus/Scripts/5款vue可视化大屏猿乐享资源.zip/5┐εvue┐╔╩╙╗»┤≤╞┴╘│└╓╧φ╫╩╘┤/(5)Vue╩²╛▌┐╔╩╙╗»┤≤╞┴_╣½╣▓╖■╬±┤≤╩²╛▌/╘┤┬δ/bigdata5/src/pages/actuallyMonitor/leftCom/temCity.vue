<template>
<!-- 市区   温度 -->
    <div class="temCity">
        <text-info class="textInfo" :pageType="pageType"/>
        <county-bar class="countyBar" :pageType="pageType"/>
        <rank-tem-city class="rankTemCity"/>
    </div>
</template>

<script>
import textInfo from './branch/textInfo'
import countyBar from './branch/countyBar'
import rankTemCity from './branch/rankTemCity'
export default {
    props:['pageType'],// to textInfo
    components:{
        textInfo,
        countyBar,
        rankTemCity,
    },
    watch:{
        
    },
    created(){
        
    }
}
</script>

<style lang="scss" scoped>
    .temCity{
        width:100%;
        height:100%;
        display:flex;
        flex-direction: column;
        .textInfo{
            width:100%;
            max-height:14rem;
        }
        .countyBar{
            width:100%;
            margin:1.5rem 0;
            height:23rem;
        }
        .rankTemCity{
            flex:1;
        }
    }
</style>