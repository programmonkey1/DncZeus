<template>
    <div class="windCity">
        <text-info class="textInfo" :pageType="pageType"/>
        <div class="windCounty">
            <h3 class="title">各区县实况风速排名|m/s</h3>
            <ul class="rank">
                <li v-for="(item,index) of rankes" :key="index" :style="{'background-image':'url(../../../../../static/images/actuallyMonitor/'+(index+1)+'.png)'}">
                    <span v-show="index<3" style="font-size:2.2rem;display:block;margin:1.3rem 0 .5rem 0;">{{item.value}}</span>
                    <span v-show="index<3" style="display:block;font-size:.8rem;">{{item.grade}}</span>
                    <span v-show="index<3" style="color:#fff;display:block;margin-top:.5rem;">{{item.name}}</span>
                    <span v-show="index>2" style="color:#fff;display:block;margin:.8rem 0 .8rem 0">{{item.name}}</span>
                    <span v-show="index>2" style="font-size:1.2rem;">{{item.value}}{{unit}}</span>
                    <span v-show="pageType=='wind-city'&&index>2" style="font-size:.7rem;">{{item.grade}}</span>
                </li>
            </ul>
        </div>
        <squared-nine class="squaredNine" :pageType="pageType"/>
    </div>
</template>

<script>
import textInfo from './branch/textInfo'
import squaredNine from './branch/squaredNine'
export default {
    props:['pageType'],// to textInfo
    components:{
        textInfo,
        squaredNine,
    },
    data(){
        return{
            rankes:[
                {name:'市区',value:1.2,grade:'一级'},
                {name:'乐清市',value:1.2,grade:'一级'},
                {name:'永嘉县',value:1.1,grade:'一级'},
                {name:'洞头区',value:1.0,grade:'一级'},
                {name:'瑞安市',value:0.9,grade:'一级'},
                {name:'平阳县',value:0.8,grade:'一级'},
                {name:'文成县',value:0.8,grade:'一级'},
                {name:'泰顺县',value:0.7,grade:'一级'},
                {name:'苍南县',value:0.6,grade:'一级'},
            ]
        }
    },
    watch:{
    },
    created(){
        
    }
}
</script>

<style lang="scss" scoped>
    .windCity{
        width:100%;
        height:100%;
        display:flex;
        flex-direction: column;
        .textInfo{
            height:12rem;
        }
        .windCounty{
            margin:3rem 0;
            height:22rem;
            background-image: url('../../../../static/images/actuallyMonitor/bar.png');
            background-repeat: no-repeat;
            background-size: 100% 100%;
            .title{
                line-height:2.4rem;
                letter-spacing: .2rem;
                font-size:1.2rem;
                height:2.4rem;
                border:.1rem solid rgba(48, 138, 199, 0.5);
                box-shadow: 0rem 0rem .5rem .1rem rgba(48, 138, 199, 0.5) inset;
                width:100%;
                margin-bottom:1.5rem;
                text-align:left;
                padding-left:1rem;
                box-sizing: border-box;
            }
            .rank{
                flex:1;
                display:flex;
                flex-wrap: wrap;
                li{
                    width:32%;
                    background-repeat: no-repeat;
                    background-size:100% 100%;
                    margin:0 2% 2% 0;
                    text-align:center;
                    &:nth-child(3n){
                        margin-right: 0;
                    }
                    &:nth-child(-n+3){
                        height:7rem;
                    }
                    &:nth-child(n+4){
                        height:4.3rem;
                    }
                }
            }
        }
        .squaredNine{
            flex:1;
        }
    }
</style>