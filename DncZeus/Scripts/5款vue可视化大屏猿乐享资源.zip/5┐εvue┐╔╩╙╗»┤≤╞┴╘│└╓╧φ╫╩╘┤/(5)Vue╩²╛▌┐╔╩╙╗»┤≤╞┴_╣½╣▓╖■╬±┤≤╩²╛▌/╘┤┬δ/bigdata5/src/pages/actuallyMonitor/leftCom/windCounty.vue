<template>
    <div class="windCounty">
        <text-info class="textInfo" :pageType="pageType"/>  
        <div class="windTown">
            <h3 class="title">各区县实况风速排名|m/s</h3>
            <ul class="top3">
                <li v-for="(item,index) of top3" :key="index" :style="{'background-image':'url(../../../../../static/images/actuallyMonitor/'+(index+1)+'.png)'}">
                    <span v-show="index<3" style="font-size:2.2rem;display:block;margin:1.3rem 0 .5rem 0;">{{item.value}}</span>
                    <span v-show="index<3" style="display:block;font-size:.8rem;">{{item.grade}}</span>
                    <span v-show="index<3" style="color:#fff;display:block;margin-top:.5rem;">{{item.name}}</span>
                </li>
            </ul>
            <ul class="surplus">
                <li v-for="(item,index) of surplus" :key="index" :style="{'background-image':'url(../../../../../static/images/actuallyMonitor/rankBg/green.png)'}">
                    <span style="position:absolute;color:#fff;left:.8rem;top:.5rem;">{{index+4}}</span>
                    <span style="color:#fff;display:block;margin:.8rem 0 .8rem 0">{{item.name}}</span>
                    <span style="font-size:1.2rem;">{{item.value}}{{unit}}</span>
                    <span style="font-size:.7rem;">{{item.grade}}</span>
                </li>
            </ul>
        </div>      
    </div>
</template>

<script>
import textInfo from './branch/textInfo'
export default {
    props:['pageType'],// to textInfo
    components:{
        textInfo,
    },
    data(){
        return{
             rankes:[
                {name:'市区',value:1.2,grade:'一级'},
                {name:'乐清市',value:1.2,grade:'一级'},
                {name:'永嘉县',value:1.1,grade:'一级'},
                {name:'洞头区',value:1.0,grade:'一级'},
                {name:'瑞安市',value:0.9,grade:'一级'},
                {name:'平阳县',value:0.8,grade:'一级'},
                {name:'文成县',value:0.8,grade:'一级'},
                {name:'泰顺县',value:0.7,grade:'一级'},
                {name:'苍南县',value:0.6,grade:'一级'},
                {name:'桐浦镇',value:1.0,grade:'一级'},
                {name:'鹤盛镇',value:0.9,grade:'一级'},
                {name:'山门镇',value:0.8,grade:'一级'},
                {name:'雁荡镇',value:0.8,grade:'一级'},
                {name:'泗溪镇',value:0.7,grade:'一级'},
                {name:'赤溪镇',value:0.6,grade:'一级'},
                {name:'什阳镇',value:0.6,grade:'一级'},
                {name:'仙溪镇',value:0.5,grade:'一级'},
                {name:'碧莲镇',value:0.4,grade:'一级'},
                {name:'宜山镇',value:0.4,grade:'一级'},
                {name:'淡溪镇',value:0.4,grade:'一级'},
                {name:'枫林镇',value:0.4,grade:'一级'},
                {name:'玉壶镇',value:0.3,grade:'一级'},
                {name:'巨屿镇',value:0.3,grade:'一级'},
                {name:'西坑镇',value:0.3,grade:'一级'},
                {name:'彭溪镇',value:0.2,grade:'一级'},
                {name:'三魁镇',value:0.2,grade:'一级'},
            ],
            top3:[],
            surplus:[],
        }
    },
    methods:{
        dataFilter(){
            this.top3 = this.rankes.slice(0,3)
            this.surplus = this.rankes.slice(3,this.rankes.length)
        }
    },
    created(){
        this.dataFilter()
    }
}
</script>

<style lang="scss" scoped>
    .windCounty{
        width:100%;
        height:100%;
        display:flex;
        flex-direction: column;
        .textInfo{
            height:12rem;
        }
        .windTown{
            flex:1;
            margin-top:1rem;
            background-image: url('../../../../static/images/actuallyMonitor/bar.png');
            background-repeat: no-repeat;
            background-size: 100% 100%;
            .title{
                line-height:2.4rem;
                letter-spacing: .2rem;
                font-size:1.2rem;
                height:2.4rem;
                border:.1rem solid rgba(48, 138, 199, 0.5);
                box-shadow: 0rem 0rem .5rem .1rem rgba(48, 138, 199, 0.5) inset;
                width:100%;
                margin-bottom:1rem;
                text-align:left;
                padding-left:1rem;
                box-sizing: border-box;
            }
            .top3{
                display:flex;
                flex-wrap: wrap;
                padding:.8rem 0;
                border-bottom:1px dashed #7FC7EA;
                li{
                    height:7.2rem;
                    width:32%;
                    background-repeat: no-repeat;
                    background-size:100% 100%;
                    margin:0 2% 2% 0;
                    text-align:center;
                    &:nth-child(3n){
                        margin-right: 0;
                    }
                }
            }
            .surplus{
                height:35rem;
                display:flex;
                flex-wrap: wrap;
                margin-top:.8rem;
                overflow: auto;
                li{
                    width:32%;
                    background-repeat: no-repeat;
                    background-size:100% 100%;
                    height:4.2rem;
                    margin:0 2% 2% 0;
                    text-align:center;
                    position: relative;
                    &:nth-child(3n){
                        margin-right: 0;
                    }
                }
            }
        }
    }
</style>