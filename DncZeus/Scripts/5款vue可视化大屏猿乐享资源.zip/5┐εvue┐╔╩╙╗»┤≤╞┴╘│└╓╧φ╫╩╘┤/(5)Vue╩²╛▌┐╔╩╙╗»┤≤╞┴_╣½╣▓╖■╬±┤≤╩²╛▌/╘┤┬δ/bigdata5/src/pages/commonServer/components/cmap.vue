<template>
    <div class="cmap">
        <div class="blank"></div>
        <div class="main">
            <div class="text">
                <span>
                    <ul>
                        <li v-for="(item,index) of numArr" :key="index">{{item}}</li>
                    </ul>
                </span>
                <h3>温州台风网近一年累计访问人次</h3>
            </div>
            <div id="cmapChart" class="cmapChart"></div>
            <div id="cmapChart2" class="cmapChart2"></div>
        </div>
    </div>
</template>

<script>
import "echarts/map/js/china.js";
import 'echarts/map/js/world.js'
import { geoCoordMap, pvData } from "../js/data";
import {worldPositions,worldPvData} from '../js/world'
import {ledSetValue} from '../js/led'
const gpsCenter = [120.19, 30.26,6];
export default {
    data(){
        return{
            mapId:1,
            numArr:[1,2,5,6,8,9],//近一年访问量数据
            option:{
                geo3D:{
                    map: 'china',
                    roam: false,
                    regionHeight: 5,
                    shading:'lambert',
                    viewControl:{
                        alpha:60
                    },
                    itemStyle: {
                        color: '#52A9E9',
                        opacity: 1,
                        borderWidth: 0.4,
                        borderColor: 'rgb(30, 101, 172)'// 地图边配色
                    },
                    // top:'-10%',
                    bottom:'0',
                    emphasis:{
                        label:{
                            show:false,
                            textStyle: {
                                color: '#fff',
                                fontSize: 10,
                                backgroundColor: 'rgba(0,23,11,0)'
                            }
                        },
                        itemStyle:{
                            color:'rgb(16, 214, 240)',
                        }
                    }
                },
                series:[
                    {
                        name: "城市",
                        type: "scatter3D",
                        coordinateSystem: "geo3D",
                        symbol:'circle',
                        symbolSize: 10,
                        data: this.convertData(
                          pvData
                            .sort(function(a, b) {
                              return b.value - a.value;
                            })
                            .slice(6, pvData.length + 1)
                        ),
                        emphasis:{
                            itemStyle:{
                                color:'rgb(223, 241, 62)'
                            },
                            label:{
                                show:true,
                                textStyle: {
                                    color: 'rgb(223, 241, 62)',
                                    fontSize: 13,
                                    padding:[0,4],
                                    backgroundColor: 'rgba(0,23,11,.4)'
                                },
                                rich:{
                                    num:{fontSize:16,padding:[0,4]},
                                },
                                formatter:(val)=>{
                                    return val.data.name+val.data.value[3]
                                }
                            }
                        },
                        label: {
                          show:false,
                        },
                        itemStyle: {
                          normal: {
                            color: "rgb(102, 238, 12)"//圆圈的颜色
                          }
                        }
                    },
                    {
                        name: "前6",
                        type: "scatter3D",
                        coordinateSystem: "geo3D",
                        data: this.convertData(
                          pvData
                            .sort(function(a, b) {
                              return b.value - a.value;
                            })
                            .slice(0, 6)
                        ),
                        symbolSize: function(val) {
                          return 10+val[3] / 100000;//圆圈的大小
                        },
                        label: {
                          normal: {
                            rich:{
                                zj:{color:'red'}
                            },
                            formatter: function(params) {
                                if(params.data.name=='浙江'){
                                    return params.data.name;
                                }else{
                                    return params.data.name;
                                }                        
                            },
                            position: "right",
                            show: true,
                            textStyle:{
                                color:'#02FD32',
                                backgroundColor:'',
                            }
                          }
                        },
                        emphasis:{
                            itemStyle:{
                                color:'rgb(223, 241, 62)'
                            },
                            label:{
                                show:true,
                                textStyle: {
                                    color: 'rgb(223, 241, 62)',
                                    fontSize: 13,
                                    padding: 4,
                                    backgroundColor: 'rgba(0,23,11,.7)'
                                },
                                rich:{
                                    num:{fontSize:16,padding:[0,4]},
                                },
                                formatter:(val)=>{
                                    return val.data.name+" "+val.data.value[3]
                                }
                            }
                        },
                        itemStyle: {
                          normal: {
                            color: "#02FD32",
                            shadowBlur: 10,
                            shadowColor: "#333"
                          }
                        },
                        zlevel: 1
                    },
                    {
                        type: 'lines3D',
                        coordinateSystem: 'geo3D',
                        effect: {
                            show: true,
                            trailWidth: 2,
                            trailOpacity: 1,
                            trailLength: 0.2,
                            constantSpeed: 5
                        },
                        blendMode: 'lighter',
                        lineStyle: { //航线的视图效果
                            color: '#EBE806',
                            width: 1,
                            opacity: 1
                        },
                        data:this.getLines(geoCoordMap,gpsCenter)
                    }
                ]
            },
            option2:{
                geo3D:{
                    map: 'world',
                    roam: false,
                    regionHeight: 5,
                    shading:'lambert',
                    viewControl:{
                        alpha:60
                    },
                    itemStyle: {
                        color: '#52A9E9',
                        opacity: 1,
                        borderWidth: 0.4,
                        borderColor: 'rgb(30, 101, 172)'// 地图边配色
                    },
                    // top:'-10%',
                    bottom:'0',
                    emphasis:{
                        label:{
                            show:false,
                            textStyle: {
                                color: '#fff',
                                fontSize: 10,
                                backgroundColor: 'rgba(0,23,11,0)'
                            }
                        },
                        itemStyle:{
                            color:'rgb(16, 214, 240)',
                        }
                    }
                },
                series:[
                    {
                        type: "scatter3D",
                        coordinateSystem: "geo3D",
                        symbolSize:10,
                        data:[{name:'温州',value:[120.19, 30.26,6]}],
                        label:{
                            formatter:'温州',
                            position: "bottom",
                            show: true,
                            textStyle:{
                                color:'#EBE806',
                                backgroundColor:'',
                            },
                        },
                        itemStyle: {
                            normal: {
                              color: "#EBE806",
                              shadowBlur: 10,
                              shadowColor: "#333"
                            }
                        },
                    },
                    {
                        name: "",
                        type: "scatter3D",
                        coordinateSystem: "geo3D",
                        data: this.worldConvertData(worldPvData),
                        symbolSize: function(val) {
                          return val[3]/20;//圆圈的大小
                        },
                        label: {
                          normal: {
                            formatter: function(params) {
                                return params.data.name;                     
                            },
                            position: "right",
                            show: true,
                            textStyle:{
                                color:'#02FD32',
                                backgroundColor:'',
                            }
                          }
                        },
                        emphasis:{
                            itemStyle:{
                                color:'rgb(223, 241, 62)'
                            },
                            label:{
                                show:true,
                                textStyle: {
                                    color: 'rgb(223, 241, 62)',
                                    fontSize: 13,
                                    padding: 4,
                                    backgroundColor: 'rgba(0,23,11,.7)'
                                },
                                rich:{
                                    num:{fontSize:16,padding:[0,4]},
                                },
                                formatter:(val)=>{
                                    return val.data.name+" "+val.data.value[3]
                                }
                            }
                        },
                        itemStyle: {
                          normal: {
                            color: "#02FD32",
                            shadowBlur: 10,
                            shadowColor: "#333"
                          }
                        },
                        zlevel: 1
                    },
                    {
                        type: 'lines3D',
                        coordinateSystem: 'geo3D',
                        effect: {
                            show: true,
                            trailWidth: 2,
                            trailOpacity: 1,
                            trailLength: 0.2,
                            constantSpeed: 5
                        },
                        blendMode: 'lighter',
                        lineStyle: { //航线的视图效果
                            color: '#EBE806',
                            width: 1,
                            opacity: 1
                        },
                        data:this.worldGetLines(worldPvData,worldPositions,gpsCenter)
                    }
                ]
            }
        }
    },
    methods:{
        init(){
            var cmapChart = document.getElementById('cmapChart')
            var cmapChart2 = document.getElementById('cmapChart2')
            let fsize = document.body.clientWidth/1920*16
            cmapChart.style.height =document.body.clientWidth<=1920? fsize*37+'px':'37rem'
            cmapChart2.style.height =document.body.clientWidth<=1920? fsize*37+'px':'37rem'
            var myChart = this.$echarts.init(cmapChart); 
            myChart.setOption(this.option)  
            var myChart2 = this.$echarts.init(cmapChart2); 
            myChart2.setOption(this.option2)    
        },
        convertData(pvData) {
            // console.log(pvData)name:'--',value:'--'
            var res = [];
            for (var i = 0; i < pvData.length; i++) {
              var geoCoord = geoCoordMap[pvData[i].name];
              if (geoCoord) {
                res.push({
                  name: pvData[i].name,
                  value: geoCoord.concat(6).concat(pvData[i].value),//经度，维度，高度
                });
              }
            }
            console.log(res)
            return res;
        },
        getLines(geoCoordMap,gpsCenter){
            let startDatas = []
            for(let k in geoCoordMap){
                geoCoordMap[k].push(6)
                startDatas.push(geoCoordMap[k])
            }
            let endDatas = []
            for(let i=0;i<startDatas.length;i++){
                let arr = []
                arr[0] = startDatas[i]
                arr[1] = gpsCenter
                endDatas.push(arr)
            }
            return endDatas
        },
        worldConvertData(pvData) {
            var res = [];
            for (var i = 0; i < pvData.length; i++) {
              var geoCoord = worldPositions[pvData[i].name];
              if (geoCoord) {
                res.push({
                  name: pvData[i].name,
                  value: geoCoord.concat(6).concat(pvData[i].value),//经度，维度，高度
                });
              }
            }
            console.log(res)
            return res;
        },   
        worldGetLines(pvData,geoCoordMap,gpsCenter){
            let startDatas = []
            for(let i=0;i<pvData.length;i++){
                for(let k in geoCoordMap){
                    if(pvData[i].name==k){
                        geoCoordMap[k].push(6)
                        startDatas.push(geoCoordMap[k])
                    }
                }
            }
            let endDatas = []
            for(let i=0;i<startDatas.length;i++){
                let arr = []
                arr[0] = startDatas[i]
                arr[1] = gpsCenter
                endDatas.push(arr)
            }
            console.log(startDatas)
            return endDatas
        },
    },
    mounted(){
        this.init()
        console.log(cmapChart.clientWidth,cmapChart.clientHeight)
    }
}
</script>
<style lang="scss" scoped>
@font-face{
    font-family:'fontled';
    src:url('../js/led.ttf')//ttf/woff都行
}
    .cmap{
        display:flex;
        flex-direction: column;
        overflow: hidden;
        .blank{
            width:100%;
            height:4rem;
            // background-color: rgb(102, 238, 12);
        }
        .main{
            flex:1;
            background-image: url('../../../../static/images/commonServer/gridCenter.png');
            background-repeat: no-repeat;
            background-size: 100% 100%;
            position:relative;
            transform-style: preserve-3d;
            perspective:62rem;
            overflow: hidden;
            .text{
                position:absolute;
                left:0;
                top:0;
                width:100%;
                height:6rem;
                text-align:center;
                ul{
                    display:inline-block;
                    margin:1rem auto 0;
                    li{
                        float:left;
                        margin:0 .3rem;
                        font-family: fontled;
                        color:#A3C9F5;
                        line-height:3.5rem;
                        font-size:3rem;
                        font-weight:600;
                        width:3rem;
                        height:4rem;
                        background-image: url('../../../../static/images/commonServer/numBg.png');
                        background-repeat: no-repeat;
                        background-size: 100% 100%;
                    }
                }
                h3{
                    color:#CFECFF;
                    font-size:1.4rem;
                }
            }
            .cmapChart{
                width:100%;
                position:absolute;
                top:10%;
                animation: arc 12s linear normal infinite;
            }
            .cmapChart2{
               width:100%;
                position:absolute;
                top:10%;
                animation: arc2 12s linear normal infinite;
            }
        }
    }
@keyframes arc {
  0% {
    opacity:0;
    z-index:0;
  }
  49% {
    opacity:0;
    z-index:0;
  }
  50%{
    transform: translateZ(600px);
    opacity:1;
    z-index:1;
  }
  55%{
    transform: translateZ(0);
    opacity:1;
    z-index:1
  }
  100%{
    transform: translateZ(0px);
    opacity:1;
    z-index:1;
  }
}
@keyframes arc2 {
  0% {
    opacity:1;
    z-index: 1;
    transform: translateZ(600px);
  }
  5%{
    opacity:1;
    z-index: 1;
    transform: translateZ(0px);
  }
  49% {
    opacity:1;
    z-index: 1;
    transform: translateZ(0px);
  }
  50%{
    transform: translateZ(0px);
    opacity:0;
    z-index:0;
  }
  100%{
    transform: translateZ(0px);
    opacity:0;
    z-index:0;
  }
}
</style>