<template>
    <div class="today">
        <h3 class="title">今日气象服务人数</h3>
        <div class="datas">
            <h3><span class="num">7,896</span><span>人次</span></h3>
        </div>
    </div>
</template>

<script>
export default {

}
</script>

<style lang="scss" scoped>
    .today{
        flex:1;
        padding:.3rem 1.4rem .5rem 1.8rem;
        .title{
            line-height:2.8rem;
            letter-spacing: .2rem;
            font-size:1.2rem;
            text-align:left;
            height:3.5rem;
        }
        .datas{
            height:6rem;
            width:100%;
            background-image: url('../../../../static/images/commonServer/todayBg.png');
            background-size: 100% 100%;
            background-repeat: no-repeat;
            h3{
                text-align:center;
                height:100%;
                line-height: 6rem;
                .num{
                    color:#FFFFFA;
                    font-size:2rem;
                    margin-right:1rem;
                    letter-spacing: .2rem;
                    text-shadow:0 0 1rem rgb(3, 40, 250);
                }
            }
        }
    }
</style>