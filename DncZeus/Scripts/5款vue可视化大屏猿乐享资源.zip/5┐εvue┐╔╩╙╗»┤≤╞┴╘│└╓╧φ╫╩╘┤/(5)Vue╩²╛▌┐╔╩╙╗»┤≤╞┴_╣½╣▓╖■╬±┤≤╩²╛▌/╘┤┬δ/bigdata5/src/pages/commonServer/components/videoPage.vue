<template>
    <div class="videoPage">
        <h3 class="title">气象影视</h3>
        <div class="videoBox">
            <video style="width:100%;height:100%;object-fit:fill" src="../../../../static/images/commonServer/typhoon.mp4" controls="controls"/>
        </div>
    </div>
</template>

<script>
export default {

}
</script>

<style lang="scss" scoped>
    .videoPage{
        display: flex;
        flex-direction: column;
        padding-bottom:1rem;
        .title{
            line-height:2.8rem;
            letter-spacing: .2rem;
            font-size:1.2rem;
            text-align:left;
            height:2.8rem;
            margin-left:1.5rem;
        }
        .videoBox{
            width:90%;
            height:15rem;
            margin:0 auto;
        }
    }
</style>