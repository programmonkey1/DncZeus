<template>
    <div class="commonServer" id="commonServer">
        <div class="title"></div>
        <div class="main">
            <div class="left">
                <today style="flex:1;"/>
                <source-page style="flex:1.4;"/>
                <pv-today style="flex:1.5;"/>               
                <video-page style="flex:1.6;"/>
            </div>
            <div class="center">
                <cmap style="flex:2.5"/>
                <pre-month style="flex:1"/>
            </div>
            <div class="right">
                <leiji style="flex:1.7"/>
                <province-page style="flex:1"/>
            </div>
        </div>
    </div>
</template>

<script>
import today from './components/today'
import videoPage from './components/videoPage'
import pvToday from './components/pvToday'
import sourcePage from './components/sourcePage'
import cmap from './components/cmap'
import preMonth from './components/preMonth'
import leiji from './components/leiji'
import provincePage from './components/provincePage'
export default {
    components:{
        today,
        videoPage,
        pvToday,
        sourcePage,
        cmap,
        preMonth,
        leiji,
        provincePage
    },
    data(){
        return{

        }
    },
    mounted(){
    }
}
</script>

<style lang="scss" scoped>
    .commonServer{
        width:100%;
        height:67.5rem;
        padding:1rem;
        overflow: hidden;
        display:flex;
        flex-direction: column;
        box-sizing: border-box;
        color:#61DEFA;
        background-image: url('../../../static/images/commonServer/bg.png');
        background-size: 100% 100%;
        background-repeat: no-repeat;
        .title{
            width:100%;
            height:3rem;
        }
        .main{
            flex:1;
            display:flex;
            div{
                flex:1;
            }
            .left{
                background-image: url('../../../static/images/commonServer/left.png');
                background-size: 100% 100%;
                background-repeat: no-repeat;
                display:flex;
                flex-direction: column;
            }
            .center{
                flex:1.4;
                margin:0 1.5rem;
                display:flex;
                flex-direction: column;
            }
            .right{
                display:flex;
                flex-direction: column;
            }
        }
    }
</style>