// Copyright © 青岛研锦网络科技有限公司, All Rights Reserved.
import Vue from 'vue'
import Router from 'vue-router'
import actuallyMonitor from '@/pages/actuallyMonitor'
import Monitormap2 from '@/pages/actuallyMonitor/components/radar/map2'
import commonServer from '@/pages/commonServer'
Vue.use(Router)

export default new Router({
  routes: [
    {
      path: '/',
      redirect:'/commonServer'
    },
    {
      path:'/actuallyMonitor',
      name: 'actuallyMonitor',
      component: actuallyMonitor
    },
    {
      path:'/commonServer',
      name:'commonServer',
      component:commonServer
    },
    {
      path:'/Monitormap2',
      name:'Monitormap2',
      component:Monitormap2
    }
  ]
})
